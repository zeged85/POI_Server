ALTER TABLE Users
ADD password int;