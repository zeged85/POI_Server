CREATE TABLE POIs(
POI_id int, 


PRIMARY KEY (POI_id)
);