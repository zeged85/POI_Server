create table Reviews_of_1(
id int IDENTITY,
review varchar(255),
username varchar(255),
daytime varchar(255),

primary key (id)
);