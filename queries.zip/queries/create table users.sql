CREATE TABLE Users(
username varchar(255), 
id int,

PRIMARY KEY (username)
);